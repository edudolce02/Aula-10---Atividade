package com.example.aula_10_atividade

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
